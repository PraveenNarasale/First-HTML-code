// JavaScript code to change the content of the paragraph
document.addEventListener("DOMContentLoaded", function () {
    // Find the paragraph element by its ID
    var paragraph = document.getElementById("demo");

    // Change its text content
    paragraph.textContent = "JavaScript has updated this content.";
});
